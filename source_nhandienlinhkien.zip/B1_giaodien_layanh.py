import cv2
from tkinter import END, NW, W, Button, Entry, Label, Tk,Canvas
import PIL.Image, PIL.ImageTk
import lib.xulianh as xulianh
from lib.serial_module import serial_port,timer_data
import os

video = cv2.VideoCapture(0)
class form():
    def __init__(self,namegui):
        #khoi tao bien
        self.camera_sw = 0
        self.arduino = serial_port("/dev/ttyACM0",9600)
        self.arduino.root.open()
        self.timer1 = timer_data(2,self.capture)
        self.index = 0
        self.sl_anh = 50
        self.timer_sw = 0

        #khoi tao giao dien
        self.root = Tk()
        self.root.title(namegui)
        Tk_Width = 1030
        Tk_Height = 500
        x_Left = int(self.root.winfo_screenwidth()/2 - Tk_Width/2)
        y_Top = int(self.root.winfo_screenheight()/2 - Tk_Height/2)
        self.root.geometry("{}x{}+{}+{}".format(Tk_Width,Tk_Height,x_Left, y_Top))


        #khoi tao phan tu
        #=> khoi tao tieu de canvas
        self.canvas_hi = video.get(cv2.CAP_PROP_FRAME_HEIGHT)
        self.canvas_wi = video.get(cv2.CAP_PROP_FRAME_WIDTH)
        self.canvas_name = Label(self.root,text="Realime camera",bg="green",anchor="center")
        self.canvas_name.place(x=0,y=0,width=self.canvas_wi,height= 20)
        #=> khoi tao canvas
        self.canvas = Canvas(self.root, bg="white")
        self.canvas.place(x=0,y=20,width=self.canvas_wi,height= self.canvas_hi)

        #=> khoi tao nut nhan camera
        self.btn_start = Button(self.root,text="Start",bg="green",command=self.camera)
        self.btn_start.place(x=800,y=455,width=80,height=40)

        #=> khoi tao o nhap ten san pham
        self.lb_tensanpham = Label(self.root,text="Ten san pham :" )
        self.lb_tensanpham.place(x=645,y=0,width=100,height=20)
        self.o_tensanpham = Entry(self.root,textvariable="")
        self.o_tensanpham.place(x=660,y=20,width=350,height=20)
        
        #=> khoi tao o nhap thong tin
        self.lb_giasanpham = Label(self.root,text="Gia san pham : ")
        self.lb_giasanpham.place(x=645,y=40,width=100,height=20)
        self.o_giasanpham = Entry(self.root,textvariable="")
        self.o_giasanpham.place(x=660,y=60,width=350,height=20)

        #=> khoi tao o nhap duong link
        self.lb_linksanpham = Label(self.root,text="Url san pham : ")
        self.lb_linksanpham.place(x=645,y=80,width=100,height=20)    
        self.o_linksanpham = Entry(self.root,textvariable="")
        self.o_linksanpham.place(x=660,y=100,width=350,height=20)

        #=> khoi tao nut nhan lay anh
        self.btn_getimage = Button(self.root,text="get Image",bg="green",command=self.getimage)
        self.btn_getimage.place(x=660,y=130,width=120,height=60)

        #=> khoi tao canvas phu 
        self.canvas_result =Canvas(self.root,bg="green")
        self.canvas_result.place(x=660,y=200,width=350,height= 250)

        #=> khoi tao thong bao
        self.thongbao = Label(text="None",anchor="center",bg="red")
        self.thongbao.place(x=800,y=130,width=210,height=60)

    def capture(self):
        if(self.camera_sw == 1 and self.index < self.sl_anh):
            #luu anh vao file arduino
            filename = "data/" + self.tenthumuc + "/" + str(self.index)+ ".jpg"
            cv2.imwrite(filename,self.frame)

            #show ra man hinh
            img = cv2.resize(self.frame_canvas,(350,250))
            self.photo_result = PIL.ImageTk.PhotoImage(image=PIL.Image.fromarray(img))
            self.canvas_result.create_image(0, 0, image=self.photo_result, anchor=NW)
            self.thongbao.configure(text= str(self.index+1)+ "/" + str(self.sl_anh))

            #gui tin hieu arduino
            self.arduino.root.write("a\n".encode())
            self.index = self.index + 1
        else:
            self.thongbao.configure(None)

    def getimage(self):
        #khoi dong timer 1
        if(self.timer_sw == 0):
            self.timer1.start()
            self.timer_sw = 1

        if(self.camera_sw == 1):
            #reset index
            self.index = 0 
            #create new data
            self.tenthumuc = self.o_tensanpham.get()
            self.giasanpham = self.o_giasanpham.get()
            self.linksanpham = self.o_linksanpham.get()
            os.mkdir("data/"+ self.tenthumuc)
            f = open("data/"+self.tenthumuc+"/readme.txt","w")
            f.write(self.tenthumuc+'\n')
            f.write(self.giasanpham+'\n')
            f.write(self.linksanpham+'\n')
            f.close()

    def run(self):
        self.root.mainloop()

    def camera(self):
        self.camera_sw = 1 - self.camera_sw
        if(self.camera_sw == 1):
            self.update_camera()
            self.btn_start.configure(text="Stop")
            self.btn_start.configure(bg="red")
        else:
            self.btn_start.configure(text="Start")
            self.btn_start.configure(bg="green")

    def update_camera(self):
            #get img
            ret,self.frame = video.read() 
            self.frame = cv2.GaussianBlur(self.frame,(5,5),0)
            self.frame = xulianh.Sharpen(self.frame)
            self.frame_canvas = cv2.resize(self.frame, dsize=None, fx=1, fy=1)
            self.frame_canvas= cv2.cvtColor(self.frame, cv2.COLOR_BGR2RGB)
            #show canvas
            self.photo = PIL.ImageTk.PhotoImage(image=PIL.Image.fromarray(self.frame_canvas))
            self.canvas.create_image(0, 0, image=self.photo, anchor=NW)

            #xuli camera
            if(self.camera_sw==1):
                self.root.after(5, self.update_camera)
            else:
                self.canvas.create_image(0, 0, image=None, anchor=NW)

giaodien = form("Giao dien lay anh")
giaodien.run()