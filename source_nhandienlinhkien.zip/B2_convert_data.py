import cv2
import glob
import numpy as np
import pickle   

x_train = []
y_train = []
value = 0

#lay thu muc
from tkinter import filedialog
path = filedialog.askdirectory()
foders = glob.glob(path + "/*")

f = open("info/label_data.txt","w")
for foder in foders:
    #in chi so
    print(foder+str(value))

    #ghi anh
    for filename in glob.glob(foder+"/*.jpg"):
        img = cv2.resize(cv2.imread(filename), (150,150))
        x_train.append(img)
        y_train.append(value)

    #ghi data
    w = open(foder+"/readme.txt",'r')
    f.write(str(value))
    f.write(",")
    f.write(w.readline().split('\n')[0])
    f.write(',')
    f.write(w.readline().split('\n')[0])
    f.write(',')    
    f.write(w.readline().split('\n')[0])
    f.write('\n')
    w.close()

    #tang chi so
    value = value + 1

f.close()


#convert data.pckle
x_train = np.array(x_train)
y_train = np.array(y_train)
print(x_train.shape)
print(y_train.shape)
with open("info/data.pickle", "wb") as f:
    pickle.dump((x_train, y_train),f)