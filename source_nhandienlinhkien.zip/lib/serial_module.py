import serial
import threading

class serial_port():
    def __init__(self,port_name,buad_rate):
        self.root = serial.Serial()
        self.root.port = port_name
        self.root.baudrate = buad_rate

    def open(self):
        if self.root.is_open == False:
            self.root.open()

    def close(self):
        if self.root.is_open == True:
            self.root.close()   


class timer_data:
    def __init__(self,time,fuc=None):
        self.time = time
        self.fuc = fuc

    def start(self):
        self.root = threading.Timer(self.time,function=self.tick)
        self.root.start()

    def tick(self):
        if self.fuc != None:
            self.fuc()

        self.root = threading.Timer(self.time,function=self.tick)
        self.root.start()

    def pause(self):
        self.root.cancel()