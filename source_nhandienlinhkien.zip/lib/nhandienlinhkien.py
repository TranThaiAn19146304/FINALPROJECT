#module
from tensorflow import keras
import numpy as np
import cv2

#load model
model = keras.models.load_model('model/model_v2.h5')


#gan nhan 
f = open("info/label_data.txt","r")
label_ten = []
label_gia = []
label_link = []

while 1 :
  line = f.readline().split('\n')[0]
  if line != "":
    label_ten.append(line.split(',')[1])
    label_gia.append(line.split(',')[2])
    label_link.append(line.split(',')[3])
  else:
    break


#lay anh
def nhandang(img):
    img = cv2.resize(img,(150,150))
    img = img.astype('float32')
    img /= 255
    img = img.reshape(1,150,150,3)
    index = np.argmax(model.predict(img))
    text1 = label_ten[index]
    text2 = label_gia[index]
    text3 = label_link[index]
    return text1,text2,text3





