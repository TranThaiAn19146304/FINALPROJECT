import cv2
from tkinter import END, NW, W, Button, Entry, Label, Tk,Canvas
import PIL.Image, PIL.ImageTk
import lib.nhandienlinhkien as ketqua
import lib.xulianh as xulianh
import webbrowser
video = cv2.VideoCapture(0)

class form():
    def __init__(self,namegui):
        #khoi tao bien
        self.camera_sw = 0

        #khoi tao giao dien
        self.root = Tk()
        self.root.title(namegui)
        Tk_Width = 1280
        Tk_Height = 500
        x_Left = int(self.root.winfo_screenwidth()/2 - Tk_Width/2)
        y_Top = int(self.root.winfo_screenheight()/2 - Tk_Height/2)
        self.root.geometry("{}x{}+{}+{}".format(Tk_Width,Tk_Height,x_Left, y_Top))
        
        #khoi tao phan tu
        #=> khoi tao tieu de 1
        self.canvas_hi = video.get(cv2.CAP_PROP_FRAME_HEIGHT)
        self.canvas_wi = video.get(cv2.CAP_PROP_FRAME_WIDTH)
        self.canvas_name = Label(self.root,text="Realime camera",bg="green",anchor="center")
        self.canvas_name.place(x=0,y=0,width=self.canvas_wi,height= 20)
        #=> khoi tao canvas1
        self.canvas = Canvas(self.root, bg="white")
        self.canvas.place(x=0,y=20,width=self.canvas_wi,height= self.canvas_hi)

        #=> khoi tao nut nhan camera
        self.btn_start = Button(self.root,text="Start",bg="green",command=self.btn_start_event)
        self.btn_start.place(x=750,y=340,width=160,height=80)

        #=> khoi tao canvas 2
        self.canvas_result = Canvas(self.root, bg="red")
        self.canvas_result.place(x=640,y=0,width=250,height=200)

        #=> khoi tao nut nhan nhan dang
        self.btn_detect = Button(self.root,text="Detect",command=self.btn_detect_event)
        self.btn_detect.place(x=1000,y=340,width=160,height=80)

        #=> khoi tao thong tin
        self.thongbao_name = Label(self.root,text="None",bg="green")
        self.thongbao_name.place(x=890,y=0,width=390,height=150)

        self.thongbao_gia = Label(self.root,text="None",bg="red")
        self.thongbao_gia.place(x=890,y=150,width=390,height=50)

        self.thongbao_url = Label(self.root,bg="green",text="url",anchor="center")
        self.thongbao_url.place(x=640,y=200,width=60,height=25)
        self.thongbao_link = Entry(self.root,textvariable="")
        self.thongbao_link.place(x=700,y=200,width=500,height=25)

        self.btn_request = Button(self.root,text="Search",bg="green",command=self.btn_request_event)
        self.btn_request.place(x=1200,y=200,width=80,height=25)
    def run(self):
        self.root.mainloop()


    #xu li canvas1 
    def btn_start_event(self):
        self.camera_sw = 1 - self.camera_sw
        if(self.camera_sw == 1):
            self.update_camera()
            self.btn_start.configure(text="Stop")
            self.btn_start.configure(bg="red")
        else:
            self.btn_start.configure(text="Start")
            self.btn_start.configure(bg="green")       

    def btn_detect_event(self):
        #show canvas result
        self.frame_result = cv2.resize(self.frame_show,(250,200))
        self.photo_result = PIL.ImageTk.PhotoImage(image=PIL.Image.fromarray(self.frame_result))
        self.canvas_result.create_image(0, 0, image=self.photo_result, anchor=NW)
        
        #show thong tin
        self.thongbao_name.configure(text=self.text_result) 
        self.thongbao_gia.configure(text= " GIA : " + self.text_gia + " VND ")
        self.thongbao_link.delete(0,END)
        self.thongbao_link.insert(0,self.text_link)


    def btn_request_event(self):
        webbrowser.open_new_tab(self.text_link)


    def update_camera(self):
        #get img
        ret,self.frame = video.read() 
        self.frame = cv2.GaussianBlur(self.frame,(5,5),0)
        self.frame = xulianh.Sharpen(self.frame)
        self.text_result,self.text_gia,self.text_link = ketqua.nhandang(self.frame)
        
        #ghi nhan
        font = cv2.FONT_HERSHEY_SIMPLEX
        org = (50, 50)
        fontScale = 0.7
        color = (255, 0, 0)
        thickness = 2
        self.frame_show = cv2.putText(self.frame, self.text_result, org, font, fontScale, color, thickness, cv2.LINE_AA)

        #show canvas
        self.frame_show = cv2.resize(self.frame_show, dsize=None, fx=1, fy=1)
        self.frame_show = cv2.cvtColor(self.frame_show, cv2.COLOR_BGR2RGB)
        self.photo = PIL.ImageTk.PhotoImage(image=PIL.Image.fromarray(self.frame_show))
        self.canvas.create_image(0, 0, image=self.photo, anchor=NW)
        if(self.camera_sw==1):
            self.root.after(5, self.update_camera)

giaodien = form("Nhan dien linh kien")
giaodien.run()